from django.shortcuts import render
import requests
import json 

# Create your views here.

def home(request):
	data = []
	url = "https://covid-193.p.rapidapi.com/statistics"
	query = {"country":"Uganda"}

	headers = {
	    'x-rapidapi-key': "73ec1201ccmshad09d534162b2d7p10fb58jsnc29ae17a4f9a",
	    'x-rapidapi-host': "covid-193.p.rapidapi.com"
	    }

	response = requests.request("GET", url, headers=headers, params =query ).json()

	data = response["response"]

	d = data[0]

	print(d)

	context = {

	'all':d['cases']['total'], 
	'Recovered':d['cases']['recovered'], 
	'Death':d['deaths']['total'],
	'New':d['cases']['new'],
	'Critical':d['cases']['critical'],
	'Time':d['time']

	}

	return render(request, 'index.html',context )